#include <stdio.h>
#include <second_before_main.h>
const int map_length=1024;
const int map_width=1024;

geo warmap[map_length][map_width];
map<string,atom>;