#include <stdio.h>
void forward(int ipt_direction){
    
}