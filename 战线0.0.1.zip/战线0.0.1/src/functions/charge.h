#include <stdio.h>
#include <iostream>
//template<typename Tatom,typename Tposition>
void charge(int ipt_bring_type,
            int ipt_order_direction
           ) {
    int attack_length;
    int attack_width;
    int attack_height;
    int attack_strength;
    switch(ipt_bring_type) {
    case 0:
        attack_length=6;
        attack_width=3;
        attack_height=1;
        attack_strength=100;
        break;
    case 1:
        break;
    default:
        break;
    }
    switch(ipt_order_direction) {
    case 12:
		
        break;
    default:
        break;
    }
}