#include <iostream>

#include "functions/main_start.h"
#include "functions/charge.h"
#include "functions/move.h"

using namespace std;


typedef struct geo {
    int height;
    int type;


} geo;




typedef struct position {
    int x;
    int y;
    int air;
} position;
typedef struct order {
    int order_type;
    int order_direction;
} order;
class atom
{
public:
    int zhenying;

    int bring_type;
    int bring_num;
    int bring_hp;

    int people_type;
    int people_num;
    int people_hp;
    int people_shiqi;

    order order_now;

    int moving_type;
    position pos;

    int be_pressed;
    int be_pressed_direction;

    int attack_type;
    position attack_begin_point;
    position attack_end_point;

    atom(int ipt_zhenying,//阵营

         int ipt_bring_type,//所带有的装备
         int ipt_bring_num,//带了多少装备
         int ipt_bring_hp,//装备耗损计数

         int ipt_people_type,//人的类型
         int ipt_people_num,//多少人
         int ipt_people_hp,//人的健康程度
         int ipt_people_shiqi,//士气

         order ipt_order_now,//现在执行的命令

         int ipt_moving_type,//移动方式
         position ipt_pos,//位置

         int ipt_be_pressed,//是否被压制
         int ipt_be_pressed_direction,//被压制方向

         int ipt_attack_type,//攻击指数
         position ipt_attack_begin_point,//攻击范围起始点
         position ipt_attack_end_point//攻击范围结束点
        ) {
        this->zhenying=ipt_zhenying;

        this->bring_type=ipt_bring_type;
        this->bring_num=ipt_bring_num;
        this->bring_hp=ipt_bring_hp;

        this->people_type=ipt_people_type;
        this->people_num=ipt_people_num;
        this->people_hp=ipt_people_hp;
        this->people_shiqi=ipt_people_shiqi;

        this->order_now=ipt_order_now;

        this->moving_type=ipt_moving_type;
        this->pos=ipt_pos;

        this->be_pressed=ipt_be_pressed;
        this->be_pressed_direction=ipt_be_pressed_direction;

        this->attack_type=ipt_attack_type;
        this->attack_begin_point=ipt_attack_begin_point;
        this->attack_end_point=ipt_attack_end_point;
    }

    void update() {
        switch((this->order_now).order_type)
        {
        case 0://休整
            (this->people_hp)++;
            break;
        case 1://冲锋
            charge(this->bring_type,
                   (this->order_now).order_direction
                  );
            move((this->order_now).order_direction);
            break;
        default:
            break;
        }
    };
};