#include <iostream>
#include "before_main.h"

using namespace std;

int main(int argc, char** argv) {
    printf("正常");
    /*while(1){

    }*/

}